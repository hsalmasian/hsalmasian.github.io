The files in this directory are executable. They should be executed by the following command:

java -jar filename.jar 


